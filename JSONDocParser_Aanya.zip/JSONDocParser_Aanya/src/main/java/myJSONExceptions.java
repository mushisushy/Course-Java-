
public class myJSONExceptions extends Exception {
    public myJSONExceptions(String message) {
        super(message);
    }
}