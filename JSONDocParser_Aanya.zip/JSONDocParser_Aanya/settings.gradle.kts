rootProject.name = "untitled2"

